/* stub added to keep compilation happy */

void ctxsw(short * reg1, short * reg2){}