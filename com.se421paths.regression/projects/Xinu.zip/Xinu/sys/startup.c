/* stub for compilation w/o asm */
void restart() {}
