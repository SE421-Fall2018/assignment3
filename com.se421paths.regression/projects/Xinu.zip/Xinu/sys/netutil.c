
/** stubs added to keep compilation happy for asm functions */

short		hs2net(){}	/* host to network short	*/
short		net2hs(){}	/* network to host short	*/
long		hl2net(){}	/* host-to-network long		*/
long		net2hl(){}	/* network to host long		*/
long		hl2vax(){}	/* pdp11-to-vax long		*/
long		vax2hl(){}	/* vax-to-pdp11 long		*/
short		cksum(){}	/* 1s comp of 16-bit 2s comp sum*/
